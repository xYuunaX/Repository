/////////////////////////////////////////////////////////////////////////////
//
// Filesystem crypto code for APFS
//
// Copyright (c) 2018-2019 Paragon Software Group, All rights reserved.
//
/////////////////////////////////////////////////////////////////////////////
//
// This file is under the terms of the GNU General Public License, version 2.
// http://www.gnu.org/licenses/gpl-2.0.html
//
//
// UNLESS OTHERWISE AGREED IN A WRITING SIGNED BY THE PARTIES, THIS SOFTWARE IS
// PROVIDED "AS-IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
// PARTICULAR PURPOSE, ALL OF WHICH ARE HEREBY DISCLAIMED. IN NO EVENT SHALL THE
// AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF NOT ADVISED OF
// THE POSSIBILITY OF SUCH DAMAGE.
//
///////////////////////////////////////////////////////////////////////////////

#ifndef __UCipher_H
#define __UCipher_H

struct UCipher
{
  struct crypto_cipher    *tfm;
  struct crypto_blkcipher *blk_tfm;
  struct crypto_skcipher  *sk_tfm;
  struct skcipher_request *req;
  struct crypto_shash     *shash;
  struct sdesc            *sdesc;

  void*         key;
  unsigned int  key_len;
};


struct crypt_operations {
  int (*init)(struct UCipher*, const char *cipher_name);
  int (*set_key)(struct UCipher*, const void *key, unsigned int key_len);
  void (*release)(struct UCipher*);
  int (*decrypt)(struct UCipher*, const void *enc_data, unsigned int enc_size, void *iv, void *dec_data, unsigned int *dec_size);
  int (*encrypt)(struct UCipher*, const void *dec_data, unsigned int dec_size, void *iv, void *enc_data, unsigned int *enc_size);

  int (*shash_init)(struct UCipher*);
  int (*shash_update)(struct UCipher*, const void *buf, unsigned int buf_size);
  int (*shash_final)(struct UCipher*, void *outbuf);
};

extern const struct crypt_operations crypt_op;


#ifdef UFSD_VFS // ufsdvfs.c only
int
readline( struct file *f, char* buf, int length )
{
  int i = 0;
  ssize_t ret = 0;
  if ( buf == NULL ) {
    return 0;
  }
  if ( f == NULL ) {
    return 0;
  }
  for ( i = 0; i < length; i++ )
    buf[i] = 0;
  i = 0;
  for ( i = 0; i < length; i++ ) {
#if is_decl( KERNEL_READ )
    ret = kernel_read( f, &(buf[i]), 1, &f->f_pos );
#else
    ret = vfs_read( f, &(buf[i]), 1, &f->f_pos );
#endif
    if ( ret <= 0 )
      break;
    if ( buf[i] == '\n' || buf[i] == '\0' )
      break;
    if ( buf[i] == '\r' )
      --i;
  }
  return i;
}


int
parse_pass_file( struct file *f, char **pass_array )
{
  int subvolume = 0;
  int pass_len = 0;
  loff_t i = 0;
  char buf[136];
  loff_t cnt = 0;

  while ( (i = readline( f, buf, 136 )) > 0 ) {
    if ( buf[0] != 'p' || buf[1] != 'a' || buf[2] != 's' || buf[3] != 's' ) {
      printk( KERN_ALERT "ufsd: wrong pass file format\n" );
      break;
    }
    if ( i > 135 ) {
      i = 135;
    }
    if ( buf[i] == '\n' ) {
      buf[i] = '\0';
    }
    if ( buf[i] != '\0' ) {
      printk( KERN_ALERT "ufsd: wrong pass file format\n" );
      break;
    }
    for ( i = 0; i < 136; i++ ) {
      if ( buf[i] == '=' )
        break;
    }
    if ( i > 7 ) {
      printk( KERN_ALERT "ufsd: wrong pass file format\n" );
      break;
    }

    pass_len = buf[i + 1] ? strlen(&(buf[i + 1])) : 0;

    if ( pass_len > MAX_APFS_PASSPHRASE_LENGTH ) {
      printk( KERN_ALERT "ufsd: wrong pass file format\n" );
      break;
    }

    subvolume = (short int)simple_strtoul( &(buf[4]), NULL, 0 ) - 1;

    if ( subvolume < 0 || subvolume >= MAX_APFS_VOLUMES ) {
      printk( KERN_ALERT "ufsd: wrong pass file format\n" );
      break;
    }

    if ( NULL != pass_array[subvolume] )
      kfree( pass_array[subvolume] );
    pass_array[subvolume] = kzalloc( pass_len + 1, GFP_KERNEL );
    if ( NULL == pass_array[subvolume] )
      return -ENOMEM;

    strncpy( pass_array[subvolume], &(buf[i + 1]), pass_len );
    ++cnt;
  }

  if ( 0 == cnt )
    printk( KERN_ALERT "No password found in the passfile" );

  return !cnt;
}
#endif // #ifdef UFSD_VFS
#endif
