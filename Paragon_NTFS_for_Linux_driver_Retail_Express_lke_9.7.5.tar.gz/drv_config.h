#define UFSD_FAKE_HFS_JOURNAL 1
#define UFSD_NTFS_NO_JNL 1
#define PACKAGE_TAG "lke_9.7.5_b1335"
#define DEFAULT_MOUNT_OPTIONS "showdots"
